# Copyright (c) OpenMMLab. All rights reserved.
from .quantization import dequantize, quantize

__all__ = ['quantize', 'dequantize']
